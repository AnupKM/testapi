# Related Blog Posts

* [API-First Development with Spring Boot and Swagger](https://reflectoring.io/spring-boot-openapi/)

## To run locally:

* run ``` mvn clean package ```

* run ```.jar``` file or run ```OpenAPIConsumerApp.main()```

* Test using browser ```http://localhost:8080/v2/user/Petros```